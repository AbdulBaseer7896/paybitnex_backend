"""
Rate views:
- GET  /rates/                   → list current rates (any authenticated user)
- GET  /rates/history/           → rate change history (staff)
- POST /rates/override/          → manual override (admin/accountant)
- POST /rates/refresh/           → trigger an immediate live fetch (admin)
"""
from datetime import timedelta
from django.utils import timezone
from rest_framework import viewsets, status
from rest_framework.decorators import action, api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.generics import ListAPIView

from myapp.Models.Audit_models import AuditLog
from myapp.Models.Rate_models import ExchangeRate, ExchangeRateHistory
from myapp.serializers.Rate_serializers import (
    ExchangeRateSerializer, ExchangeRateHistorySerializer,
    ManualRateOverrideSerializer,
)
from myapp.Utils.permissions import IsAdmin, IsAdminOrAccountant


class ExchangeRateListView(ListAPIView):
    permission_classes = [IsAuthenticated]
    queryset = ExchangeRate.objects.select_related("currency").all()
    serializer_class = ExchangeRateSerializer
    pagination_class = None


class ExchangeRateHistoryView(ListAPIView):
    permission_classes = [IsAuthenticated, IsAdminOrAccountant]
    queryset = ExchangeRateHistory.objects.all()
    serializer_class = ExchangeRateHistorySerializer
    filterset_fields = ["currency_code", "source"]
    ordering = ["-created_at"]


@api_view(["POST"])
@permission_classes([IsAuthenticated, IsAdminOrAccountant])
def manual_override(request):
    s = ManualRateOverrideSerializer(data=request.data)
    s.is_valid(raise_exception=True)
    code = s.validated_data["currency"]
    rate_value = s.validated_data["rate_to_pkr"]
    hours = s.validated_data.get("override_hours", 24)

    try:
        rate = ExchangeRate.objects.get(currency_id=code)
        before = {
            "rate_to_pkr": str(rate.rate_to_pkr),
            "source": rate.source,
        }
    except ExchangeRate.DoesNotExist:
        rate = ExchangeRate(currency_id=code)
        before = None

    rate.rate_to_pkr = rate_value
    rate.source = ExchangeRate.SOURCE_MANUAL
    rate.manual_override_until = timezone.now() + timedelta(hours=hours)
    rate.updated_by = request.user
    rate.save()

    ExchangeRateHistory.objects.create(
        currency_code=code,
        rate_to_pkr=rate_value,
        source=ExchangeRate.SOURCE_MANUAL,
        set_by=request.user,
    )
    AuditLog.record(
        user=request.user, action=AuditLog.ACTION_RATE_CHANGE, target=rate,
        description=f"Manual override {code} = {rate_value} PKR for {hours}h",
        before=before, after={"rate_to_pkr": str(rate_value), "source": "manual"},
    )
    return Response(ExchangeRateSerializer(rate).data)


@api_view(["POST"])
@permission_classes([IsAuthenticated, IsAdmin])
def trigger_refresh(request):
    """Queue an immediate rate-fetch task."""
    from myapp.Utils.rate_tasks import fetch_live_rates
    try:
        fetch_live_rates.delay()
    except Exception:
        # If Celery isn't running, run inline (safe for dev)
        fetch_live_rates.apply(throw=False)
    return Response({"detail": "Rate refresh queued."})
