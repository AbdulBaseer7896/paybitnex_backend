"""
Transaction workflow views. This is the heart of PayBitnex.

Customer:
    POST /transactions/payments/        → submit new payment
    GET  /transactions/payments/        → list own payments
    GET  /transactions/payments/{id}/   → detail

Accountant / Admin:
    GET  /transactions/payments/         → see all (with filters)
    POST /transactions/payments/{id}/apply/    → set rate + fee → verify
    POST /transactions/payments/{id}/status/   → set reject / on_hold / manual
    POST /transactions/transfers/              → record outgoing PKR transfer
        (marks incoming payment as PKR_SENT + COMPLETED + distributes fees)
"""
from decimal import Decimal
from django.db import transaction as dbtx
from django.utils import timezone
from rest_framework import viewsets, status, mixins
from rest_framework.decorators import action
from rest_framework.exceptions import ValidationError
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from myapp.Models.Auth_models import UserRole
from myapp.Models.Audit_models import AuditLog
from myapp.Models.Transaction_models import (
    IncomingPayment, OutgoingPKRTransfer, TransactionStatus,
    TransactionStatusHistory,
)
from myapp.serializers.Transaction_serializers import (
    IncomingPaymentSerializer, IncomingPaymentCreateSerializer,
    AccountantApplySerializer, OutgoingTransferCreateSerializer,
    OutgoingTransferSerializer, StatusUpdateSerializer,
)
from myapp.Utils.permissions import IsAdminOrAccountant
from myapp.Utils.references import next_reference
from myapp.Utils.partner_ledger import distribute_fee_for_payment


# ---------- helpers ----------

def _record_status_change(payment, from_status, to_status, user, note=""):
    TransactionStatusHistory.objects.create(
        payment=payment,
        from_status=from_status,
        to_status=to_status,
        changed_by=user,
        note=note,
    )
    AuditLog.record(
        user=user, action=AuditLog.ACTION_STATE_CHANGE, target=payment,
        description=f"{payment.reference}: {from_status} → {to_status}",
        before={"status": from_status}, after={"status": to_status},
    )


# ---------- viewsets ----------

class IncomingPaymentViewSet(viewsets.ModelViewSet):
    """
    Mixed-role viewset.
    Customers see their own; staff see everything (with filters).
    """
    permission_classes = [IsAuthenticated]
    queryset = (
        IncomingPayment.objects
        .select_related("customer", "currency", "merchant_account__bank", "handled_by")
        .prefetch_related("status_history__changed_by")
        .all()
    )
    filterset_fields = ["status", "currency", "customer"]
    search_fields = [
        "reference", "external_transaction_id",
        "sender_name", "sender_company", "customer__email",
    ]
    ordering_fields = ["created_at", "amount", "status"]

    def get_serializer_class(self):
        if self.action == "create":
            return IncomingPaymentCreateSerializer
        return IncomingPaymentSerializer

    def get_queryset(self):
        u = self.request.user
        if u.role == UserRole.CUSTOMER:
            return self.queryset.filter(customer=u)
        return self.queryset

    # ---- customer submit ----
    def create(self, request, *args, **kwargs):
        if request.user.role != UserRole.CUSTOMER:
            return Response(
                {"detail": "Only customers can submit payments."},
                status=status.HTTP_403_FORBIDDEN,
            )
        s = IncomingPaymentCreateSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        with dbtx.atomic():
            ref = next_reference(IncomingPayment, prefix="PBX")
            payment = IncomingPayment.objects.create(
                customer=request.user,
                reference=ref,
                status=TransactionStatus.SUBMITTED,
                **s.validated_data,
            )
            _record_status_change(
                payment, from_status="", to_status=TransactionStatus.SUBMITTED,
                user=request.user, note="Submitted by customer",
            )
        return Response(
            IncomingPaymentSerializer(payment).data,
            status=status.HTTP_201_CREATED,
        )

    # ---- accountant: apply rate + fee ----
    @action(
        detail=True, methods=["post"],
        permission_classes=[IsAuthenticated, IsAdminOrAccountant],
        url_path="apply",
    )
    def apply_rate_and_fee(self, request, pk=None):
        payment = self.get_object()
        s = AccountantApplySerializer(data=request.data)
        s.is_valid(raise_exception=True)

        if payment.status in (TransactionStatus.PKR_SENT, TransactionStatus.COMPLETED):
            return Response(
                {"detail": "Cannot modify a completed payment."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        before_status = payment.status
        with dbtx.atomic():
            payment.exchange_rate = s.validated_data["exchange_rate"]
            payment.fee_percentage = s.validated_data["fee_percentage"]
            if "accountant_notes" in s.validated_data:
                payment.accountant_notes = s.validated_data["accountant_notes"]
            payment.calculate_amounts()
            payment.handled_by = request.user

            if s.validated_data.get("mark_verified") and payment.status != TransactionStatus.VERIFIED:
                payment.status = TransactionStatus.VERIFIED
                payment.verified_at = timezone.now()
            elif payment.status == TransactionStatus.SUBMITTED:
                payment.status = TransactionStatus.UNDER_REVIEW

            payment.save()

            if before_status != payment.status:
                _record_status_change(
                    payment, before_status, payment.status,
                    user=request.user, note="Rate + fee applied",
                )

        return Response(IncomingPaymentSerializer(payment).data)

    # ---- accountant: set status (reject / hold / manual) ----
    @action(
        detail=True, methods=["post"],
        permission_classes=[IsAuthenticated, IsAdminOrAccountant],
        url_path="status",
    )
    def set_status(self, request, pk=None):
        payment = self.get_object()
        s = StatusUpdateSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        new_status = s.validated_data["status"]
        if new_status not in TransactionStatus.values:
            raise ValidationError({"status": "Invalid status."})
        before = payment.status
        payment.status = new_status
        payment.handled_by = request.user
        payment.save(update_fields=["status", "handled_by", "updated_at"])
        _record_status_change(
            payment, before, new_status,
            user=request.user, note=s.validated_data.get("note", ""),
        )
        return Response(IncomingPaymentSerializer(payment).data)


class OutgoingTransferViewSet(
    mixins.ListModelMixin, mixins.RetrieveModelMixin,
    mixins.CreateModelMixin, viewsets.GenericViewSet,
):
    """
    Accountant records the PKR transfer. On create:
    - marks the IncomingPayment as PKR_SENT then COMPLETED,
    - runs partner fee distribution,
    - logs status history + audit.
    """
    permission_classes = [IsAuthenticated, IsAdminOrAccountant]
    queryset = (
        OutgoingPKRTransfer.objects
        .select_related("incoming_payment", "customer_bank_account__bank", "sent_by")
        .all()
    )
    serializer_class = OutgoingTransferSerializer
    filterset_fields = ["sent_by", "customer_bank_account"]
    search_fields = ["reference", "bank_transaction_id"]

    def get_serializer_class(self):
        if self.action == "create":
            return OutgoingTransferCreateSerializer
        return OutgoingTransferSerializer

    def create(self, request, *args, **kwargs):
        s = OutgoingTransferCreateSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        payment: IncomingPayment = s.validated_data["incoming_payment"]

        if payment.status in (TransactionStatus.PKR_SENT, TransactionStatus.COMPLETED):
            raise ValidationError({"incoming_payment": "Already settled."})
        if payment.net_pkr is None:
            raise ValidationError({
                "incoming_payment":
                "Payment has no rate/fee applied. Apply rate first.",
            })

        with dbtx.atomic():
            before_status = payment.status
            ref = next_reference(OutgoingPKRTransfer, prefix="OUT")
            transfer = OutgoingPKRTransfer.objects.create(
                reference=ref,
                sent_by=request.user,
                **s.validated_data,
            )
            payment.status = TransactionStatus.PKR_SENT
            payment.handled_by = request.user
            payment.completed_at = timezone.now()
            payment.save(update_fields=[
                "status", "handled_by", "completed_at", "updated_at",
            ])
            _record_status_change(
                payment, before_status, TransactionStatus.PKR_SENT,
                user=request.user, note=f"PKR sent — ref {transfer.reference}",
            )

            # Distribute fees across partners
            distribute_fee_for_payment(payment)

            # Mark completed
            payment.status = TransactionStatus.COMPLETED
            payment.save(update_fields=["status", "updated_at"])
            _record_status_change(
                payment, TransactionStatus.PKR_SENT, TransactionStatus.COMPLETED,
                user=request.user, note="Auto-completed after transfer + distribution",
            )

        return Response(
            OutgoingTransferSerializer(transfer).data,
            status=status.HTTP_201_CREATED,
        )
