"""
Customer profile — personal info + CNIC verification.
CNIC images stored in Cloudinary via default storage.
"""
import uuid
from django.db import models
from django.core.validators import RegexValidator


CNIC_VALIDATOR = RegexValidator(
    regex=r"^\d{5}-?\d{7}-?\d{1}$",
    message="CNIC must be in format 12345-1234567-1 or 13 digits.",
)


class CustomerProfile(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.OneToOneField(
        "myapp.User", on_delete=models.CASCADE, related_name="profile",
    )

    # Personal
    full_name = models.CharField(max_length=150)
    phone = models.CharField(max_length=20)
    cnic_number = models.CharField(
        max_length=15, validators=[CNIC_VALIDATOR], unique=True,
    )
    cnic_front = models.ImageField(upload_to="cnic/front/")
    cnic_back = models.ImageField(upload_to="cnic/back/")

    # Address (optional, useful for KYC)
    address = models.TextField(blank=True)
    city = models.CharField(max_length=80, blank=True)

    # KYC status — accountant/admin can approve
    KYC_PENDING = "pending"
    KYC_APPROVED = "approved"
    KYC_REJECTED = "rejected"
    KYC_CHOICES = [
        (KYC_PENDING, "Pending Review"),
        (KYC_APPROVED, "Approved"),
        (KYC_REJECTED, "Rejected"),
    ]
    kyc_status = models.CharField(
        max_length=20, choices=KYC_CHOICES, default=KYC_PENDING, db_index=True,
    )
    kyc_reviewed_by = models.ForeignKey(
        "myapp.User", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="kyc_reviews",
    )
    kyc_reviewed_at = models.DateTimeField(null=True, blank=True)
    kyc_notes = models.TextField(blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "customer_profiles"

    def __str__(self):
        return f"Profile: {self.full_name} ({self.user.email})"
