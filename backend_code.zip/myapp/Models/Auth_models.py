"""
User model with role-based access: admin, accountant, customer.
Email is the login identifier (no username).
"""
import uuid
from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.utils import timezone


class UserRole(models.TextChoices):
    ADMIN = "admin", "Admin"
    ACCOUNTANT = "accountant", "Accountant"
    CUSTOMER = "customer", "Customer"


class UserManager(BaseUserManager):
    use_in_migrations = True

    def _create_user(self, email, password, **extra_fields):
        if not email:
            raise ValueError("Email is required")
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_user(self, email, password=None, **extra_fields):
        extra_fields.setdefault("is_staff", False)
        extra_fields.setdefault("is_superuser", False)
        role = extra_fields.setdefault("role", UserRole.CUSTOMER)
        if role in (UserRole.ADMIN, UserRole.ACCOUNTANT, "admin", "accountant"):
            extra_fields.setdefault("is_active", True)
            extra_fields.setdefault("email_verified", True)
            extra_fields.setdefault("verification_deadline", None)
        else:
            extra_fields.setdefault("is_active", False)
            extra_fields.setdefault("email_verified", False)
            extra_fields.setdefault("verification_deadline", None)
        return self._create_user(email, password, **extra_fields)

    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)
        extra_fields.setdefault("role", UserRole.ADMIN)
        extra_fields.setdefault("is_active", True)
        extra_fields.setdefault("is_profile_complete", True)
        extra_fields.setdefault("email_verified", True)
        extra_fields.setdefault("verification_deadline", None)
        return self._create_user(email, password, **extra_fields)


class User(AbstractBaseUser, PermissionsMixin):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    email = models.EmailField(unique=True, db_index=True)
    full_name = models.CharField(max_length=150, blank=True)
    role = models.CharField(
        max_length=20, choices=UserRole.choices, default=UserRole.CUSTOMER, db_index=True,
    )
    phone = models.CharField(max_length=20, blank=True)
    profile_picture = models.ImageField(
        upload_to="avatars/", null=True, blank=True,
    )

    # customer onboarding — must complete profile before accessing dashboard
    is_profile_complete = models.BooleanField(default=False)
    # last completed onboarding step (0 = not started, 1 = personal done,
    # 2 = CNIC done, 3 = selfie done). When the user logs back in mid-flow
    # the frontend resumes from this step instead of restarting at step 0.
    # Only meaningful while is_profile_complete is False.
    onboarding_step = models.PositiveSmallIntegerField(default=0)

    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    email_verified = models.BooleanField(default=False)
    verification_deadline = models.DateTimeField(null=True, blank=True)

    # Optional 4–8 digit PIN that locks the customer's "My Payments" page.
    # Stored as a salted hash (never plaintext). Because it lives on the
    # account (server-side), it's known across browsers/devices — but the
    # *unlocked* state is tracked per-browser in localStorage, so signing in
    # from a new browser starts locked until the PIN is entered. Blank = no
    # PIN set (page is open).
    payments_pin_hash = models.CharField(max_length=255, blank=True, default="")

    created_at = models.DateTimeField(default=timezone.now, db_index=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(
        "self", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="created_users",
    )

    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = []

    objects = UserManager()

    class Meta:
        db_table = "users"
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["role", "is_active"]),
        ]

    def __str__(self):
        return f"{self.email} ({self.role})"

    @property
    def is_admin(self):
        return self.role == UserRole.ADMIN

    @property
    def is_accountant(self):
        return self.role == UserRole.ACCOUNTANT

    @property
    def is_customer(self):
        return self.role == UserRole.CUSTOMER
