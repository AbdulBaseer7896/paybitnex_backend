"""Rate URLs."""
from django.urls import path
from myapp.Views.Rate_views import (
    ExchangeRateListView, ExchangeRateHistoryView,
    manual_override, trigger_refresh,
)

urlpatterns = [
    path("", ExchangeRateListView.as_view(), name="rates-list"),
    path("history/", ExchangeRateHistoryView.as_view(), name="rates-history"),
    path("override/", manual_override, name="rates-override"),
    path("refresh/", trigger_refresh, name="rates-refresh"),
]
