"""
Exchange rate fetching — runs every hour via Celery Beat.

Respects manual overrides: if a currency has manual_override_until set
and that datetime is in the future, we skip overwriting it.

Supported providers:
    - exchangerate-api   (https://www.exchangerate-api.com)
    - openexchangerates  (https://openexchangerates.org)

To add another provider, add a parser to `_PROVIDERS` below.
"""
import logging
from decimal import Decimal
from typing import Optional

import httpx
from celery import shared_task
from django.conf import settings
from django.utils import timezone

log = logging.getLogger(__name__)


def _parse_exchangerate_api(data: dict, wanted: list[str]) -> dict[str, Decimal]:
    """
    Response shape: {"base": "PKR", "conversion_rates": {"USD": 0.0036, ...}}
    We want 1 USD = X PKR, so we invert.
    """
    base = data.get("base_code") or data.get("base")
    rates = data.get("conversion_rates") or data.get("rates") or {}
    out = {}
    for code in wanted:
        if code == base:
            out[code] = Decimal("1")
            continue
        r = rates.get(code)
        if r is None or r == 0:
            continue
        # If base is PKR → rate is "1 PKR = r CODE" → invert for "1 CODE = ? PKR"
        if base == "PKR":
            out[code] = (Decimal("1") / Decimal(str(r))).quantize(Decimal("0.000001"))
        else:
            # base is the foreign currency; rate is CODE per base.
            out[code] = Decimal(str(r))
    return out


_PROVIDERS = {
    "exchangerate-api": {
        "url": "https://v6.exchangerate-api.com/v6/{key}/latest/PKR",
        "parser": _parse_exchangerate_api,
    },
}


async def _fetch_from_provider(wanted_codes: list[str]) -> Optional[dict[str, Decimal]]:
    provider_name = settings.EXCHANGE_RATE_PROVIDER
    api_key = settings.EXCHANGE_RATE_API_KEY
    if not api_key:
        log.warning("No EXCHANGE_RATE_API_KEY configured; skipping live fetch.")
        return None
    provider = _PROVIDERS.get(provider_name)
    if not provider:
        log.warning("Unknown rate provider: %s", provider_name)
        return None

    url = provider["url"].format(key=api_key)
    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            r = await client.get(url)
            r.raise_for_status()
            data = r.json()
        return provider["parser"](data, wanted_codes)
    except Exception as e:
        log.exception("Rate fetch failed: %s", e)
        return None


@shared_task(bind=True, max_retries=3, default_retry_delay=60)
def fetch_live_rates(self):
    """Sync wrapper for Celery. Delegates to async impl."""
    import asyncio
    try:
        return asyncio.run(_fetch_live_rates_async())
    except Exception as e:
        log.exception("fetch_live_rates failed")
        raise self.retry(exc=e)


async def _fetch_live_rates_async():
    from myapp.Models.Core_models import Currency
    from myapp.Models.Rate_models import ExchangeRate, ExchangeRateHistory

    codes = [c async for c in Currency.objects.filter(is_active=True, is_base=False).values_list("code", flat=True)]
    if not codes:
        log.info("No active non-base currencies configured.")
        return

    rates = await _fetch_from_provider(codes)
    if not rates:
        return

    now = timezone.now()
    updated = 0
    for code, rate_value in rates.items():
        try:
            current = await ExchangeRate.objects.aget(currency_id=code)
            if (
                current.source == ExchangeRate.SOURCE_MANUAL
                and current.manual_override_until
                and current.manual_override_until > now
            ):
                log.info("Skipping %s — manual override active.", code)
                continue
            current.rate_to_pkr = rate_value
            current.source = ExchangeRate.SOURCE_LIVE
            await current.asave(update_fields=["rate_to_pkr", "source", "updated_at"])
        except ExchangeRate.DoesNotExist:
            await ExchangeRate.objects.acreate(
                currency_id=code,
                rate_to_pkr=rate_value,
                source=ExchangeRate.SOURCE_LIVE,
            )

        await ExchangeRateHistory.objects.acreate(
            currency_code=code,
            rate_to_pkr=rate_value,
            source=ExchangeRate.SOURCE_LIVE,
        )
        updated += 1

    log.info("Exchange rates updated: %d currencies.", updated)
    return {"updated": updated}
