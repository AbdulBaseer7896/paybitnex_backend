"""
Aggregator module. Django expects `models.py` — we re-export
every model defined in the Models/ folder so migrations work.
"""
from myapp.Models.Auth_models import User, UserRole
from myapp.Models.Profile_models import CustomerProfile
from myapp.Models.Banking_models import (
    PakistaniBank,
    ForeignBank,
    CustomerBankAccount,
    CustomerMerchantAccount,
)
from myapp.Models.Transaction_models import (
    IncomingPayment,
    OutgoingPKRTransfer,
    OutgoingPKRTransferReceipt,
    TransactionStatusHistory,
)
from myapp.Models.Rate_models import ExchangeRate, ExchangeRateHistory
from myapp.Models.Fee_models import CustomerFeeConfig
from myapp.Models.Partner_models import Partner, PartnerShare, PartnerLedgerEntry
from myapp.Models.Report_models import DailyReport, WeeklyReport, MonthlyReport
from myapp.Models.Core_models import SystemSetting, Currency, PaymentMethod
from myapp.Models.Audit_models import AuditLog
from myapp.Models.Expense_models import Expense, ExpenseCategory, ExpenseDistribution
from myapp.Models.EmailOTP_models import EmailOTP
from myapp.Models.Invoicing_models import (
    Client, CustomerCompany, CustomerAllowedPaymentMethod,
    Invoice, InvoiceLineItem, InvoiceStatus, InvoicePaymentMethod,
)
from myapp.Models.Feature_models import CustomerFeatureAccess
from myapp.Models.InternalTx_models import (
    Vendor, USABankAccount, CreditCard, VendorPKRPayment, InternalPakistaniAccount,
    InternalTransaction,
    InternalTxSource, InternalTxDestination, InternalTxMethod,
)
from myapp.Models.Dispatch_models import (
    DispatchCompany, DispatchDriver, Dispatch, DispatchStatus,
)
from myapp.Models.BankAudit_models import BankAudit, BankAuditFile, BankStatementRecord, BankSyncJob

__all__ = [
    "User", "UserRole",
    "CustomerProfile",
    "PakistaniBank", "ForeignBank",
    "CustomerBankAccount", "CustomerMerchantAccount",
    "IncomingPayment", "OutgoingPKRTransfer", "OutgoingPKRTransferReceipt", "TransactionStatusHistory",
    "ExchangeRate", "ExchangeRateHistory",
    "CustomerFeeConfig",
    "Partner", "PartnerShare", "PartnerLedgerEntry",
    "DailyReport", "WeeklyReport", "MonthlyReport",
    "SystemSetting", "Currency", "PaymentMethod",
    "AuditLog",
    "Expense", "ExpenseCategory", "ExpenseDistribution",
    "EmailOTP",
    "Client", "CustomerCompany", "CustomerAllowedPaymentMethod",
    "Invoice", "InvoiceLineItem", "InvoiceStatus", "InvoicePaymentMethod",
    "CustomerFeatureAccess",
    # Internal transactions module
    "Vendor", "USABankAccount", "CreditCard", "VendorPKRPayment", "InternalPakistaniAccount",
    "InternalTransaction",
    "InternalTxSource", "InternalTxDestination", "InternalTxMethod",
    # Dispatch module
    "DispatchCompany", "DispatchDriver", "Dispatch", "DispatchStatus",
    # Bank reconciliation audit module
    "BankAudit", "BankAuditFile", "BankStatementRecord", "BankSyncJob",
]
