"""Serializers for the internal-transactions module."""
from decimal import Decimal

from rest_framework import serializers

from myapp.Models.InternalTx_models import (
    Vendor, USABankAccount, CreditCard, InternalPakistaniAccount,
    InternalTransaction,
    InternalTxSource, InternalTxDestination,
)


# ---------------------------------------------------------------------
# Reference data
# ---------------------------------------------------------------------

class VendorSerializer(serializers.ModelSerializer):
    class Meta:
        model = Vendor
        fields = [
            "id", "name",
            "contact_name", "contact_email", "contact_phone",
            "notes", "is_active",
            "created_at", "updated_at",
        ]
        read_only_fields = ["id", "created_at", "updated_at"]


class USABankAccountSerializer(serializers.ModelSerializer):
    bank_display = serializers.CharField(
        source="get_bank_display", read_only=True,
    )

    class Meta:
        model = USABankAccount
        fields = [
            "id", "label", "bank", "bank_display",
            "holder_name", "account_number_last4",
            "notes", "is_active",
            "created_at", "updated_at",
        ]
        read_only_fields = ["id", "bank_display", "created_at", "updated_at"]


class CreditCardSerializer(serializers.ModelSerializer):
    brand_display = serializers.CharField(
        source="get_brand_display", read_only=True,
    )

    class Meta:
        model = CreditCard
        fields = [
            "id", "label", "brand", "brand_display",
            "last4", "holder_name",
            "notes", "is_active",
            "created_at", "updated_at",
        ]
        read_only_fields = ["id", "brand_display", "created_at", "updated_at"]


class InternalPakistaniAccountSerializer(serializers.ModelSerializer):
    class Meta:
        model = InternalPakistaniAccount
        fields = [
            "id", "label", "bank_name",
            "account_title", "account_number_last4", "iban",
            "notes", "is_active",
            "created_at", "updated_at",
        ]
        read_only_fields = ["id", "created_at", "updated_at"]


# ---------------------------------------------------------------------
# Internal transaction
# ---------------------------------------------------------------------

class InternalTransactionSerializer(serializers.ModelSerializer):
    """Read + write serializer for InternalTransaction.

    Validation enforces the source/destination invariants:
      - source_type=usa_bank requires source_usa_bank, forbids source_credit_card
      - source_type=credit_card requires source_credit_card, forbids source_usa_bank
      - destination_type=usa_bank requires dest_usa_bank only
      - destination_type=vendor requires dest_vendor only
      - destination_type=pk_bank requires dest_pk_bank only
    Anything else is a 400.
    """
    source_label = serializers.CharField(read_only=True)
    destination_label = serializers.CharField(read_only=True)
    method_display = serializers.CharField(
        source="get_method_display", read_only=True,
    )
    source_type_display = serializers.CharField(
        source="get_source_type_display", read_only=True,
    )
    destination_type_display = serializers.CharField(
        source="get_destination_type_display", read_only=True,
    )
    currency_code = serializers.CharField(
        source="currency_id", read_only=True,
    )
    fee_currency_code = serializers.CharField(
        source="fee_currency_id", read_only=True,
    )
    fee_expense_id = serializers.PrimaryKeyRelatedField(
        source="fee_expense", read_only=True,
    )
    created_by_email = serializers.CharField(
        source="created_by.email", read_only=True,
    )
    created_by_name = serializers.CharField(
        source="created_by.full_name", read_only=True,
    )

    class Meta:
        model = InternalTransaction
        fields = [
            "id",
            # Source
            "source_type", "source_type_display",
            "source_usa_bank", "source_credit_card",
            "source_label",
            # Destination
            "destination_type", "destination_type_display",
            "dest_usa_bank", "dest_vendor", "dest_pk_bank",
            "destination_label",
            # Money
            "currency", "currency_code", "amount",
            "fee_amount", "fee_currency", "fee_currency_code",
            "fee_expense_id",
            # Method + meta
            "method", "method_display",
            "reference", "description", "occurred_on",
            "document",
            # Bookkeeping
            "created_by", "created_by_email", "created_by_name",
            "created_at", "updated_at",
        ]
        read_only_fields = [
            "id", "source_label", "destination_label",
            "method_display", "source_type_display", "destination_type_display",
            "currency_code", "fee_currency_code", "fee_expense_id",
            "created_by", "created_by_email", "created_by_name",
            "created_at", "updated_at",
        ]

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------
    def validate(self, data):
        # When PATCHing, the existing instance fills gaps left by the
        # partial payload. Build the merged view we want to validate.
        merged = {}
        if self.instance is not None:
            for f in (
                "source_type", "destination_type",
                "source_usa_bank", "source_credit_card",
                "dest_usa_bank", "dest_vendor", "dest_pk_bank",
                "amount", "fee_amount", "currency", "fee_currency",
            ):
                merged[f] = getattr(self.instance, f, None)
        merged.update(data)

        src = merged.get("source_type")
        dst = merged.get("destination_type")

        # ── Source validation ────────────────────────────────────────
        if src == InternalTxSource.USA_BANK:
            if not merged.get("source_usa_bank"):
                raise serializers.ValidationError({
                    "source_usa_bank":
                        "Required when source_type is 'usa_bank'.",
                })
            if merged.get("source_credit_card"):
                raise serializers.ValidationError({
                    "source_credit_card":
                        "Must be empty when source_type is 'usa_bank'.",
                })
        elif src == InternalTxSource.CREDIT_CARD:
            if not merged.get("source_credit_card"):
                raise serializers.ValidationError({
                    "source_credit_card":
                        "Required when source_type is 'credit_card'.",
                })
            if merged.get("source_usa_bank"):
                raise serializers.ValidationError({
                    "source_usa_bank":
                        "Must be empty when source_type is 'credit_card'.",
                })
        else:
            raise serializers.ValidationError({
                "source_type": "Unknown source type.",
            })

        # ── Destination validation ───────────────────────────────────
        # Helper to check that exactly the right destination FK is set.
        def require(field, allow_set):
            if not merged.get(field):
                raise serializers.ValidationError({
                    field:
                        f"Required when destination_type is '{dst}'.",
                })
            for other in ("dest_usa_bank", "dest_vendor", "dest_pk_bank"):
                if other not in allow_set and merged.get(other):
                    raise serializers.ValidationError({
                        other:
                            f"Must be empty when destination_type is '{dst}'.",
                    })

        if dst == InternalTxDestination.USA_BANK:
            require("dest_usa_bank", {"dest_usa_bank"})
        elif dst == InternalTxDestination.VENDOR:
            require("dest_vendor", {"dest_vendor"})
        elif dst == InternalTxDestination.PK_BANK:
            require("dest_pk_bank", {"dest_pk_bank"})
        else:
            raise serializers.ValidationError({
                "destination_type": "Unknown destination type.",
            })

        # ── A row can't move money to itself ─────────────────────────
        if (src == InternalTxSource.USA_BANK
                and dst == InternalTxDestination.USA_BANK):
            sub = merged.get("source_usa_bank")
            dub = merged.get("dest_usa_bank")
            # Compare PKs (both might be model instances or UUIDs).
            sub_id = getattr(sub, "pk", sub)
            dub_id = getattr(dub, "pk", dub)
            if sub_id and sub_id == dub_id:
                raise serializers.ValidationError({
                    "dest_usa_bank":
                        "Source and destination cannot be the same account.",
                })

        # ── Amount + fee sanity ──────────────────────────────────────
        amount = merged.get("amount")
        if amount is not None and Decimal(str(amount)) <= 0:
            raise serializers.ValidationError({
                "amount": "Amount must be greater than zero.",
            })
        fee = merged.get("fee_amount") or Decimal("0")
        if Decimal(str(fee)) < 0:
            raise serializers.ValidationError({
                "fee_amount": "Fee cannot be negative.",
            })

        return data
