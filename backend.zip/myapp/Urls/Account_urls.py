"""Account URLs: admin user management + customer profile + KYC review + score."""
from django.urls import path, include
from rest_framework.routers import DefaultRouter

from myapp.Views.Account_views import (
    UserAdminViewSet, CustomerProfileView,
    KYCReviewView, PendingKYCListView, KYCRaiseObjectionsView,
    CustomerScoreView, CustomerOnboardingListView,
    onboarding_counts,
)
from myapp.Views.Feature_views import UserFeaturesView

router = DefaultRouter()
router.register(r"users", UserAdminViewSet, basename="users")

urlpatterns = [
    path("", include(router.urls)),
    path("profile/", CustomerProfileView.as_view(), name="profile"),
    path("score/", CustomerScoreView.as_view(), name="my-score"),
    path("score/<int:user_id>/", CustomerScoreView.as_view(), name="user-score"),
    path("kyc/pending/", PendingKYCListView.as_view(), name="kyc-pending"),
    path("kyc/<uuid:profile_id>/review/", KYCReviewView.as_view(), name="kyc-review"),
    path("kyc/<uuid:profile_id>/objections/",
         KYCRaiseObjectionsView.as_view(), name="kyc-objections"),
    path("onboarding/", CustomerOnboardingListView.as_view(), name="onboarding-list"),
    path("onboarding/counts/", onboarding_counts, name="onboarding-counts"),
    # Alias kept for frontend code that uses the older path.
    path("customers/onboarded/", CustomerOnboardingListView.as_view(),
         name="onboarding-list-alias"),
    # Admin-only: read / write a customer's premium feature grants.
    path("users/<uuid:user_id>/features/",
         UserFeaturesView.as_view(), name="user-features"),
]
