"""
Invoice PDF renderer — designed to mirror the public web view
(`PublicInvoicePage.jsx`) as closely as reportlab allows.

Layout (matches the public page top-down):

  ┌──────────────────────────────────────────────┐
  │ [logo]  Company Name               INVOICE   │
  │         tax id · email · website   #INV-001  │
  │                                    Issued …  │
  │ ─────────────────────────────────────────── │
  │ BILL TO                                       │
  │ Client name, company, address, email          │
  │                                               │
  │ SUMMARY (if any)                              │
  │                                               │
  │ # | Item | Qty | Unit | Total                 │
  │ ────────────────────────────────────────      │
  │                                               │
  │         Subtotal   $ X                        │
  │         Tax        $ X                        │
  │         Total      $ X                        │
  │                                               │
  │ PAYMENT OPTIONS (2-col when ≥ 2)              │
  │ [ Zelle card ]     [ ACH card ]               │
  │                                               │
  │ (footer notes)                                │
  └──────────────────────────────────────────────┘
  Address · email · phone · page #  (every page bottom)

Key decisions:
  · No dark brand band — public web page doesn't have one either, so
    the PDF shouldn't. The company name sits alongside the logo in the
    normal content flow.
  · Footer has company contact + page number — every page.
  · Logo is resolved live from the Company row at render time; if
    that fails, falls back to the snapshot URL/path; if both fail,
    we log the reason and continue without a logo (never crash).
"""
import io
import logging
import os
from decimal import Decimal

from django.conf import settings
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib.enums import TA_RIGHT, TA_LEFT
from reportlab.platypus import (
    BaseDocTemplate, PageTemplate, Frame,
    Paragraph, Spacer, Table, TableStyle, Image,
    HRFlowable,
)

log = logging.getLogger(__name__)

# ── Theme ───────────────────────────────────────────────────────────
INK_HEADING = colors.HexColor("#0e1b2b")
INK_BODY    = colors.HexColor("#1f2937")
INK_MUTED   = colors.HexColor("#6b7280")
INK_BORDER  = colors.HexColor("#e5e7eb")
BRAND_SOFT  = colors.HexColor("#ecf3ef")
BRAND_RIM   = colors.HexColor("#cde0d5")


def _fmt_money(amount, currency="USD"):
    try:
        n = Decimal(str(amount or 0)).quantize(Decimal("0.01"))
    except Exception:
        n = Decimal("0.00")
    if currency == "USD":
        return f"$ {n:,.2f}"
    return f"{currency} {n:,.2f}"


def _safe(value, fallback=""):
    return str(value) if value not in (None, "") else fallback


def _resolve_image_path(candidate):
    """Return an absolute filesystem path for an image, or None.

    Accepts:
      - an absolute OS path that exists
      - a URL that we can map back to MEDIA_ROOT via MEDIA_URL
      - a bare relative path like 'customer_companies/logos/x.png'
    Emits a log warning when we have a candidate that doesn't resolve,
    so the server log tells us exactly why the logo went missing.
    """
    if not candidate:
        return None

    candidate = str(candidate)

    # 1) Already an absolute path that exists.
    try:
        if os.path.isabs(candidate) and os.path.exists(candidate):
            return candidate
    except Exception:
        pass

    # 2) URL → MEDIA_ROOT mapping.
    try:
        media_url = (settings.MEDIA_URL or "").rstrip("/")
        media_root = settings.MEDIA_ROOT
        if media_url:
            # Strip scheme://host if it's an absolute URL.
            # build_absolute_uri gives us e.g. http://host/media/x.png —
            # find "/media/" (our MEDIA_URL) and take everything after.
            idx = candidate.find(media_url)
            if idx != -1:
                rel = candidate[idx + len(media_url):].lstrip("/")
                p = os.path.join(media_root, rel)
                if os.path.exists(p):
                    return p

        # 3) Bare relative path → try under MEDIA_ROOT.
        if not candidate.startswith(("http://", "https://")):
            p = os.path.join(media_root, candidate.lstrip("/"))
            if os.path.exists(p):
                return p
    except Exception as e:
        log.warning("logo path resolve error for %r: %s", candidate, e)
        return None

    log.warning("logo path did not resolve: candidate=%r", candidate)
    return None


def _get_logo_path(invoice):
    """Best-effort resolution of the logo path for the invoice.

    Priority:
      1. live `company.logo.path` (picks up logos uploaded AFTER the
         invoice was issued)
      2. snapshot `logo_path`
      3. snapshot `logo_url`
    """
    # Live.
    try:
        if invoice.company and invoice.company.logo:
            p = invoice.company.logo.path
            if p and os.path.exists(p):
                return p
            log.warning("invoice %s: company.logo.path=%r does not exist",
                        invoice.number, p)
    except Exception as e:
        log.warning("invoice %s: reading live logo failed: %s",
                    invoice.number, e)

    # Snapshot fallbacks.
    comp = invoice.company_snapshot or {}
    return (_resolve_image_path(comp.get("logo_path"))
            or _resolve_image_path(comp.get("logo_url")))


def _get_qr_path(pm_snapshot, live_method=None):
    """Same resolution logic for the per-method QR."""
    if live_method is not None:
        try:
            if live_method.qr_code:
                p = live_method.qr_code.path
                if p and os.path.exists(p):
                    return p
        except Exception as e:
            log.warning("qr live read failed: %s", e)
    return (_resolve_image_path((pm_snapshot or {}).get("qr_code_path"))
            or _resolve_image_path((pm_snapshot or {}).get("qr_code_url")))


# ── Page-frame painters ─────────────────────────────────────────────

def _draw_footer(canvas, doc, company):
    """Compact footer with address + contact + page number.

    This runs on every page. Content on the last page already shows
    these details in the body payment section, but printing them on
    every page keeps things looking like a real letterhead.
    """
    canvas.saveState()
    width = doc.pagesize[0]
    y_rule = 54   # horizontal rule sits here

    # Thin divider rule.
    canvas.setStrokeColor(INK_BORDER)
    canvas.setLineWidth(0.4)
    canvas.line(0.6 * inch, y_rule, width - 0.6 * inch, y_rule)

    # ── Address line ──
    addr_parts = []
    for k in ("address_line1", "address_line2"):
        v = company.get(k)
        if v:
            addr_parts.append(v)
    city_line = ", ".join(filter(None, [
        company.get("city"), company.get("state"),
        company.get("postal_code"), company.get("country"),
    ]))
    if city_line:
        addr_parts.append(city_line)
    addr = " · ".join(addr_parts)

    # ── Contact line ──
    contact_parts = []
    for k in ("email", "phone", "website"):
        if company.get(k):
            contact_parts.append(_safe(company.get(k)))
    contact = " · ".join(contact_parts)

    canvas.setFillColor(INK_MUTED)
    canvas.setFont("Helvetica", 8)
    if addr:
        canvas.drawString(0.6 * inch, y_rule - 14, addr)
    if contact:
        canvas.drawString(0.6 * inch, y_rule - 26, contact)

    # Page number right-aligned.
    canvas.drawRightString(width - 0.6 * inch, y_rule - 14,
                           f"Page {canvas.getPageNumber()}")
    canvas.restoreState()


# ── Main renderer ───────────────────────────────────────────────────

def render_invoice_pdf(invoice):
    """Return a BytesIO containing the rendered invoice PDF."""
    buf = io.BytesIO()
    comp = invoice.company_snapshot or {}
    client = invoice.client_snapshot or {}

    left = 0.6 * inch
    right = 0.6 * inch
    top_margin = 0.55 * inch
    bottom_band = 60 + 0.2 * inch     # footer (2 lines + page #)

    doc = BaseDocTemplate(
        buf, pagesize=letter,
        leftMargin=left, rightMargin=right,
        topMargin=top_margin, bottomMargin=bottom_band,
        title=f"Invoice {invoice.number}",
        author=_safe(comp.get("name"), "Invoice"),
    )
    frame = Frame(
        left, bottom_band,
        doc.pagesize[0] - left - right,
        doc.pagesize[1] - top_margin - bottom_band,
        id="body", showBoundary=0,
    )
    doc.addPageTemplates([PageTemplate(
        id="main", frames=[frame],
        onPage=lambda c, d: _draw_footer(c, d, comp),
    )])

    # ── Styles ──
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(
        name="InvTitle", parent=styles["Title"], alignment=TA_RIGHT,
        fontSize=26, textColor=INK_HEADING, spaceAfter=0, leading=28,
    ))
    styles.add(ParagraphStyle(
        name="InvMutedRight", parent=styles["BodyText"],
        fontSize=9, textColor=INK_MUTED, alignment=TA_RIGHT, leading=12,
    ))
    styles.add(ParagraphStyle(
        name="InvH", parent=styles["BodyText"],
        fontSize=9, textColor=INK_MUTED,
        fontName="Helvetica-Bold", spaceAfter=3,
    ))
    styles.add(ParagraphStyle(
        name="InvBody", parent=styles["BodyText"],
        fontSize=10, textColor=INK_BODY, leading=13,
    ))
    styles.add(ParagraphStyle(
        name="InvBodyBold", parent=styles["BodyText"],
        fontSize=10, textColor=INK_BODY, leading=13,
        fontName="Helvetica-Bold",
    ))
    styles.add(ParagraphStyle(
        name="InvMuted", parent=styles["BodyText"],
        fontSize=9, textColor=INK_MUTED, leading=12,
    ))
    styles.add(ParagraphStyle(
        name="CompanyName", parent=styles["BodyText"],
        fontSize=20, textColor=INK_HEADING, leading=24,
        fontName="Helvetica-Bold",
    ))

    story = []

    # ── Top header — matches the public share page layout ──
    # Left column: logo (rounded-square placeholder if missing) +
    # company name, then a stacked block of address / email / tax id.
    # Right column: INVOICE label, number, issue & due dates.
    logo_path = _get_logo_path(invoice)

    # The "logo + company name" row — rendered as its own nested
    # 2-col table so the name aligns vertically with the logo.
    if logo_path:
        try:
            logo_cell = Image(logo_path, width=0.75 * inch,
                              height=0.75 * inch, kind="proportional")
        except Exception as e:
            log.warning("invoice pdf: logo load failed path=%r err=%s",
                        logo_path, e)
            logo_cell = Paragraph("", styles["InvBody"])
    else:
        # No logo — leave the column empty. The name then sits flush
        # left, which reads fine on a black-and-white PDF.
        logo_cell = Paragraph("", styles["InvBody"])

    name_row = Table(
        [[logo_cell, Paragraph(_safe(comp.get("name"), "Invoice"),
                                 styles["CompanyName"])]],
        colWidths=[0.9 * inch if logo_path else 0.01 * inch, None],
    )
    name_row.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING",  (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 0),
        ("TOPPADDING",   (0, 0), (-1, -1), 0),
        ("BOTTOMPADDING",(0, 0), (-1, -1), 0),
    ]))

    left_block = [name_row, Spacer(1, 6)]
    # Address block — match the public page order:
    #   address_line1 / address_line2
    #   city, state ZIP
    #   country
    #   email
    #   (tax id, website — small muted)
    addr_bits = [
        _safe(comp.get("address_line1")),
        _safe(comp.get("address_line2")),
    ]
    city_line = ", ".join(filter(None, [
        comp.get("city"), comp.get("state"), comp.get("postal_code"),
    ]))
    if city_line:
        addr_bits.append(city_line)
    if comp.get("country"):
        addr_bits.append(_safe(comp.get("country")))
    for line in [a for a in addr_bits if a]:
        left_block.append(Paragraph(line, styles["InvMuted"]))
    if comp.get("email"):
        left_block.append(Paragraph(_safe(comp.get("email")),
                                     styles["InvMuted"]))
    if comp.get("phone"):
        left_block.append(Paragraph(_safe(comp.get("phone")),
                                     styles["InvMuted"]))
    if comp.get("tax_id"):
        left_block.append(Paragraph(
            f"Tax ID: {_safe(comp.get('tax_id'))}", styles["InvMuted"],
        ))

    right_block = [
        Paragraph("INVOICE", styles["InvTitle"]),
        Paragraph(f"<b>{_safe(invoice.number, 'INV-???')}</b>",
                  styles["InvMutedRight"]),
        Spacer(1, 6),
        Paragraph(
            f"Issued: {invoice.issue_date.strftime('%b %d, %Y') if invoice.issue_date else '—'}",
            styles["InvMutedRight"],
        ),
    ]
    if invoice.due_date:
        right_block.append(Paragraph(
            f"Due: {invoice.due_date.strftime('%b %d, %Y')}",
            styles["InvMutedRight"],
        ))

    top = Table([[left_block, right_block]],
                colWidths=[4.1 * inch, 3.0 * inch])
    top.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 0),
    ]))
    story.append(top)
    story.append(Spacer(1, 14))
    story.append(HRFlowable(width="100%", thickness=0.5, color=INK_BORDER))
    story.append(Spacer(1, 16))

    # ── Bill-to ────────────────────────────────────────────────────
    story.append(Paragraph("BILL TO", styles["InvH"]))
    story.append(Paragraph(
        _safe(client.get("name"), "Client"), styles["InvBodyBold"],
    ))
    if client.get("company_name"):
        story.append(Paragraph(_safe(client.get("company_name")),
                               styles["InvBody"]))
    if client.get("address"):
        story.append(Paragraph(
            _safe(client.get("address")).replace("\n", "<br/>"),
            styles["InvMuted"],
        ))
    if client.get("email"):
        story.append(Paragraph(_safe(client.get("email")), styles["InvMuted"]))
    if client.get("phone"):
        story.append(Paragraph(_safe(client.get("phone")), styles["InvMuted"]))
    story.append(Spacer(1, 14))

    # ── General description ──
    if invoice.general_description:
        summary = Table([[Paragraph(
            _safe(invoice.general_description).replace("\n", "<br/>"),
            styles["InvBody"],
        )]], colWidths=[None])
        summary.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#f8f8f5")),
            ("BOX", (0, 0), (-1, -1), 0.4, INK_BORDER),
            ("LEFTPADDING", (0, 0), (-1, -1), 12),
            ("RIGHTPADDING", (0, 0), (-1, -1), 12),
            ("TOPPADDING", (0, 0), (-1, -1), 10),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
        ]))
        story.append(summary)
        story.append(Spacer(1, 14))

    # ── Line items ─────────────────────────────────────────────────
    header_row = ["#", "Item", "Qty", "Unit price", "Total"]
    data = [header_row]
    for i, li in enumerate(invoice.line_items.all(), start=1):
        name_cell = _safe(li.name)
        if li.description:
            name_cell = Paragraph(
                f"<b>{_safe(li.name)}</b><br/>"
                f"<font size=8 color='#6b7280'>"
                f"{_safe(li.description).replace(chr(10), '<br/>')}</font>",
                styles["InvBody"],
            )
        data.append([
            str(i), name_cell,
            f"{li.quantity:,.2f}",
            _fmt_money(li.unit_price, invoice.currency_code),
            _fmt_money(li.total, invoice.currency_code),
        ])

    items_table = Table(
        data,
        colWidths=[0.35 * inch, 3.35 * inch, 0.7 * inch,
                   1.15 * inch, 1.25 * inch],
        repeatRows=1,
    )
    items_table.setStyle(TableStyle([
        # Header
        ("LINEBELOW",     (0, 0), (-1, 0), 1.1, colors.HexColor("#374151")),
        ("TEXTCOLOR",     (0, 0), (-1, 0), INK_MUTED),
        ("FONTNAME",      (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE",      (0, 0), (-1, 0), 8.5),
        ("ALIGN",         (2, 0), (-1, -1), "RIGHT"),
        ("ALIGN",         (0, 0), (0, -1), "LEFT"),
        ("BOTTOMPADDING", (0, 0), (-1, 0), 8),
        ("TOPPADDING",    (0, 0), (-1, 0), 2),
        # Rows
        ("FONTSIZE",      (0, 1), (-1, -1), 10),
        ("TEXTCOLOR",     (0, 1), (-1, -1), INK_BODY),
        ("VALIGN",        (0, 0), (-1, -1), "TOP"),
        ("LINEBELOW",     (0, 1), (-1, -1), 0.25, INK_BORDER),
        ("TOPPADDING",    (0, 1), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 1), (-1, -1), 8),
    ]))
    story.append(items_table)
    story.append(Spacer(1, 8))

    # ── Totals (right-aligned, like web) ───────────────────────────
    totals_rows = [
        ["Subtotal", _fmt_money(invoice.subtotal, invoice.currency_code)],
    ]
    if invoice.tax_percent and invoice.tax_percent > 0:
        totals_rows.append([
            f"Tax ({invoice.tax_percent}%)",
            _fmt_money(invoice.tax_amount, invoice.currency_code),
        ])
    totals_rows.append([
        "Total",
        _fmt_money(invoice.total, invoice.currency_code),
    ])
    totals = Table(totals_rows, colWidths=[1.4 * inch, 1.4 * inch],
                   hAlign="RIGHT")
    totals.setStyle(TableStyle([
        ("FONTSIZE",   (0, 0), (-1, -2), 10),
        ("TEXTCOLOR",  (0, 0), (-1, -2), INK_MUTED),
        ("ALIGN",      (1, 0), (1, -1), "RIGHT"),
        # Total row
        ("FONTNAME",   (0, -1), (-1, -1), "Helvetica-Bold"),
        ("FONTSIZE",   (0, -1), (-1, -1), 13),
        ("TEXTCOLOR",  (0, -1), (-1, -1), INK_HEADING),
        ("LINEABOVE",  (0, -1), (-1, -1), 0.8, colors.HexColor("#9ca3af")),
        ("TOPPADDING", (0, -1), (-1, -1), 6),
    ]))
    story.append(totals)
    story.append(Spacer(1, 18))

    # ── Payment options (multi-method, matching public page) ───────
    methods = _collect_method_snapshots(invoice)
    if methods:
        label = ("PAYMENT OPTIONS" if len(methods) > 1
                 else "PAYMENT DETAILS")
        story.append(Paragraph(label, styles["InvH"]))
        if len(methods) > 1:
            story.append(Paragraph(
                "You may pay via any method below.", styles["InvMuted"],
            ))
        story.append(Spacer(1, 6))

        # 2-col grid when ≥ 2; single column otherwise.
        col_count = 2 if len(methods) >= 2 else 1
        cards = [_build_method_card(invoice, pm, styles) for pm in methods]
        while len(cards) % col_count != 0:
            cards.append("")
        rows = [cards[i:i + col_count]
                for i in range(0, len(cards), col_count)]
        col_w = (7.1 * inch) / col_count
        grid = Table(rows, colWidths=[col_w] * col_count)
        grid.setStyle(TableStyle([
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("LEFTPADDING", (0, 0), (-1, -1), 4),
            ("RIGHTPADDING", (0, 0), (-1, -1), 4),
            ("TOPPADDING", (0, 0), (-1, -1), 0),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
        ]))
        story.append(grid)
        story.append(Spacer(1, 10))

    # ── Footer notes (invoice body, not the page footer) ───────────
    if invoice.notes:
        story.append(HRFlowable(width="100%", thickness=0.4, color=INK_BORDER))
        story.append(Spacer(1, 6))
        story.append(Paragraph(
            _safe(invoice.notes).replace("\n", "<br/>"), styles["InvMuted"],
        ))

    doc.build(story)
    buf.seek(0)
    return buf


def _collect_method_snapshots(invoice):
    """Prefer the M2M list; fall back to legacy single snapshot."""
    ipms = list(invoice.invoice_payment_methods.all().order_by(
        "position", "id",
    ))
    if ipms:
        return [ipm.snapshot or {} for ipm in ipms]
    if invoice.payment_method_snapshot:
        return [invoice.payment_method_snapshot]
    return []


def _build_method_card(invoice, pm, styles):
    """Build a single payment-method card flowable.

    The card is a 1-column Table where each row is ONE flowable — this
    avoids the earlier "cell = python list" bug where reportlab couldn't
    measure height.
    """
    body_rows = [[Paragraph(
        f"<b>{_safe(pm.get('label'))}</b>", styles["InvBody"],
    )]]

    details = []
    for key, disp in [
        ("holder_name",    "Account title"),
        ("email",          "Email"),
        ("phone",          "Phone"),
        ("cashapp_tag",    "Cashtag"),
        ("account_number", "Account #"),
        ("routing_number", "Routing #"),
        ("bank_name",      "Bank"),
        ("account_type",   "Type"),
    ]:
        v = pm.get(key)
        if v:
            details.append([disp, _safe(v)])
    if details:
        dt = Table(details, colWidths=[0.95 * inch, None])
        dt.setStyle(TableStyle([
            ("FONTSIZE",  (0, 0), (-1, -1), 8.5),
            ("TEXTCOLOR", (0, 0), (0, -1),  INK_MUTED),
            ("TEXTCOLOR", (1, 0), (1, -1),  INK_BODY),
            ("VALIGN",    (0, 0), (-1, -1), "TOP"),
            ("LEFTPADDING",  (0, 0), (-1, -1), 0),
            ("RIGHTPADDING", (0, 0), (-1, -1), 0),
            ("BOTTOMPADDING",(0, 0), (-1, -1), 2),
            ("TOPPADDING",   (0, 0), (-1, -1), 0),
        ]))
        body_rows.append([dt])

    # QR code — try live method first.
    live_pm = None
    try:
        from myapp.Models.Core_models import PaymentMethod
        code = pm.get("code")
        if code:
            live_pm = PaymentMethod.objects.filter(code=code).first()
    except Exception:
        pass
    qr_path = _get_qr_path(pm, live_pm)
    if qr_path:
        try:
            body_rows.append([Image(qr_path, width=0.9 * inch,
                                     height=0.9 * inch, kind="proportional")])
        except Exception as e:
            log.warning("invoice pdf qr load failed path=%r err=%s",
                        qr_path, e)

    if pm.get("instructions"):
        body_rows.append([Paragraph(
            f"<i>{_safe(pm.get('instructions'))}</i>", styles["InvMuted"],
        )])

    card = Table(body_rows, colWidths=[None])
    card.setStyle(TableStyle([
        ("BACKGROUND",   (0, 0), (-1, -1), BRAND_SOFT),
        ("BOX",          (0, 0), (-1, -1), 0.5, BRAND_RIM),
        ("LEFTPADDING",  (0, 0), (-1, -1), 10),
        ("RIGHTPADDING", (0, 0), (-1, -1), 10),
        ("TOPPADDING",   (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING",(0, 0), (-1, -1), 6),
        ("VALIGN",       (0, 0), (-1, -1), "TOP"),
    ]))
    return card
